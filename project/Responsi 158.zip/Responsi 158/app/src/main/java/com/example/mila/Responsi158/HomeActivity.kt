package com.example.mila.Responsi158

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity() {

    val nama    = arrayOf<String>("bunga sritiw",
        "bunga dandelion",
        "bunga bangkai",
        "bunga sakura",
        "bunga raflesia",
        "bunga flambo",
        "bunga bayam",
        "bunga tulip",
        "bunga mawar",
        "bunga sepatu")

    val imageId = arrayOf<Int>(
        R.drawable.a,
        R.drawable.d,
        R.drawable.i,
        R.drawable.k,
        R.drawable.r,
        R.drawable.w,
        R.drawable.y,
        R.drawable.t,
        R.drawable.m,
        R.drawable.s

    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        val myListAdapter = ListAdapter(this,nama,imageId)
        lview.adapter = myListAdapter

        val bundle = intent.extras
        val userBro = bundle?.get("usr2").toString()
        val namaBro = bundle?.get("nama2").toString()
        val nimBro = bundle?.get("nim2").toString()
        val passBro = bundle?.get("pss2").toString()

        tombol.setOnClickListener{
            intent = Intent(this, AccountActivity::class.java)
            intent.putExtra("nim2",namaBro)
            intent.putExtra("nama2",nimBro)
            intent.putExtra("usr2",userBro)
            intent.putExtra("pss2",passBro)
            startActivity(intent)
        }

        lview.setOnItemClickListener(){adapterView, view, position, id ->
            val itemAtPos = adapterView.getItemAtPosition(position)
            val itemIdAtPos = adapterView.getItemIdAtPosition(position)

            var a = Integer.parseInt(itemIdAtPos.toString())
            var pr = a+1

            if (a.equals(0)){
                Toast.makeText(this, "bunga sritiw $itemAtPos , bunga ini indah", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(1)){
                Toast.makeText(this, "bunga dandelion $itemAtPos , aku suka bunga ini", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(2)){
                Toast.makeText(this, "bunga bangkai $itemAtPos , bunga itu tidak bau bangkai", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(3)){
                Toast.makeText(this, "bunga sakura $itemAtPos , bisa ditemukan di jepang", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(4)){
                Toast.makeText(this, "bunga raflesia $itemAtPos , termasuk bunga besar di Indonesia", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(5)){
                Toast.makeText(this, "bunga flambo $itemAtPos , flambo itu seperti lagu", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(6)){
                Toast.makeText(this, "bunga bayam $itemAtPos , sebenernya bukan bunga tapi ya sudahlah", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(7)){
                Toast.makeText(this, "bunga tulip $itemAtPos , aku suka warna kuning dari tulip", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(8)){
                Toast.makeText(this, "bunga mawar $itemAtPos , Dia adalah Teman Yang Jahat", Toast.LENGTH_LONG).show()
            }
            else if (a.equals(9)){
                Toast.makeText(this, "bunga sepatu" +
                        " $itemAtPos , lakukanlah sesuatu dengan bismillah", Toast.LENGTH_LONG).show()
            }

            else {
                Toast.makeText(this, "TIDAK ADA", Toast.LENGTH_LONG).show()
            }
        }
    }
}
